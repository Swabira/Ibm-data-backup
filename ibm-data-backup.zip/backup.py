import os, json, zipfile, datetime

with open('config.json') as f:
    config = json.load(f)

def backup():
    source = config['source']
    backup_dir = config['backup_dir']
    backup_name = config['backup_name']

    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)

    backup_path = os.path.join(backup_dir, backup_name)
    with zipfile.ZipFile(backup_path, 'w') as zipf:
        for root, _, files in os.walk(source):
            for file in files:
                zipf.write(os.path.join(root, file),
                           arcname=os.path.relpath(os.path.join(root, file), source))

    with open("backup.log", "a") as log:
        log.write(f"[{datetime.datetime.now()}] Backup completed: {backup_path}\n")

if __name__ == "__main__":
    backup()

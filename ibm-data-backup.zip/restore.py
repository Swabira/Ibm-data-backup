import os, json, zipfile

with open('config.json') as f:
    config = json.load(f)

def restore():
    backup_path = os.path.join(config['backup_dir'], config['backup_name'])
    with zipfile.ZipFile(backup_path, 'r') as zipf:
        zipf.extractall(config['source'])

if __name__ == "__main__":
    restore()

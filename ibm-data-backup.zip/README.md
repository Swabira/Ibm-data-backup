# IBM Mini Project - Data Backup and Recovery

## Description
A basic Python script to back up a directory and restore it when needed.

## Usage
- Configure `config.json`
- Run `python backup.py` to back up files
- Run `python restore.py` to restore files
